import React, { useEffect, useState } from "react";
import BoardView from "./BoardView.jsx";
import ItemPage from "./ItemPage.jsx";

function getRoute() {
  const hash = window.location.hash || "#/";
  return hash.startsWith("#/item") ? "item" : "home";
}

export default function App() {
  const [route, setRoute] = useState(getRoute());

  useEffect(() => {
    const onHashChange = () => setRoute(getRoute());
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  return route === "item" ? <ItemPage /> : <BoardView />;
}

