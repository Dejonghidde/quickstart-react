import { useEffect, useMemo, useState } from "react";
import monday from "./monday";

function getParam(name) {
  const qs = window.location.hash.split("?")[1] || "";
  return new URLSearchParams(qs).get(name);
}

export default function ItemPage() {
  const [loading, setLoading] = useState(true);
  const [item, setItem] = useState(null);

  const itemIdFromHash = useMemo(() => {
    const v = getParam("id");
    return v ? parseInt(v, 10) : null;
  }, []);

  useEffect(() => {
    let mounted = true;
    async function run() {
      setLoading(true);
      const ctx = await monday.get("context");
      const ctxItemId = ctx?.data?.itemId;
      const itemId = ctxItemId || itemIdFromHash;
      if (!itemId) { setLoading(false); return; }

      const q = `
        query($ids: [Int]) {
          items(ids: $ids) {
            id
            name
            board { id name }
            column_values { id title text value }
          }
        }
      `;
      const res = await monday.api(q, { variables: { ids: [itemId] } });
      if (mounted) setItem(res?.data?.items?.[0] || null);
      setLoading(false);
    }
    run();
    return () => { mounted = false; };
  }, [itemIdFromHash]);

  if (loading) return <div style={{ padding: 16 }}>Laden…</div>;
  if (!item) return <div style={{ padding: 16 }}>Geen item gevonden.</div>;

  const prompt1 = item.column_values.find(c => /prompt.*1/i.test(c.title))?.text || "";
  const prompt2 = item.column_values.find(c => /prompt.*2/i.test(c.title))?.text || "";
  const prompt3 = item.column_values.find(c => /prompt.*3/i.test(c.title))?.text || "";
  const media   = item.column_values.find(c => /media|url|afbeelding/i.test(c.title))?.text || "";

  return (
    <div style={{ padding: 16 }}>
      <button onClick={() => (window.location.hash = "#/")} style={{ marginBottom: 12 }}>
        ← Terug
      </button>
      <h2 style={{ margin: 0 }}>{item.name}</h2>
      <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 16 }}>
        Board: {item.board?.name} (ID {item.board?.id})
      </div>

      <section style={{ marginBottom: 16 }}>
        <h3>Prompts</h3>
        <div><strong>Prompt 1:</strong> {prompt1 || "—"}</div>
        <div><strong>Prompt 2:</strong> {prompt2 || "—"}</div>
        <div><strong>Prompt 3:</strong> {prompt3 || "—"}</div>
      </section>

      <section>
        <h3>Media</h3>
        {media ? (<a href={media} target="_blank" rel="noreferrer">Open media</a>) : "—"}
      </section>
    </div>
  );
}
