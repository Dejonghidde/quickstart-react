import React, { useEffect, useState } from "react";
import monday from "./monday"; // mondaySdk instance

export default function BoardView() {
  const [ctx, setCtx] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);

  // 1) Context ophalen (ook bij live wijzigingen)
  useEffect(() => {
    monday.get("context").then(({ data }) => setCtx(data));
    const unsub = monday.listen("context", ({ data }) => setCtx(data));
    return () => unsub && unsub();
  }, []);

// 2) Items laden zodra we een boardId hebben
useEffect(() => {
  if (!ctx) return;                 // wacht tot context er is
  console.log("CTX =>", ctx);       // debug: hele context
  if (!ctx.boardId) return;         // pas doorgaan met laden als er een boardId is

  setLoading(true);
  setErr(null);

  const query = `
    query ($boardId: [ID!]) {
      boards(ids: $boardId) {
        id
        name
        items_page(limit: 25) {
          items {
            id
            name
            column_values { id text }
          }
        }
      }
    }
  `;

  monday
    .api(query, { variables: { boardId: ctx.boardId } })
    .then(({ data, error }) => {
      if (error) throw error;
      const list = data?.boards?.[0]?.items_page?.items ?? [];
      setItems(list);
    })
    .catch((e) => setErr(String(e)))
    .finally(() => setLoading(false));
}, [ctx?.boardId]); // 🔑 opnieuw runnen als boardId wijzigt

  // UI
  return (
    <div style={{ padding: 16 }}>
      <h2 style={{ marginTop: 0 }}>BoardView — Items</h2>

      <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 12 }}>
        BoardId: {ctx?.boardId ?? "—"}
      </div>

      {loading && <div>Laden…</div>}
      {err && <div style={{ color: "#e74c3c" }}>Fout: {err}</div>}

      {!loading && !err && (
        <>
<div style={{ color: "white", padding: 16 }}>
  <h3>BoardView — Items</h3>
  <p>BoardId: {ctx.boardId}</p>
  <ul>
    {items.map((it) => (
      <li key={it.id}>{it.name || "(naamloos)"} — ID {it.id}</li>
    ))}
  </ul>
</div>

          {items.length === 0 ? (
            <div>Geen items gevonden op dit bord.</div>
          ) : (
		<ul style={{ paddingLeft: 16 }}>
 		 {items.map((it) => (
 		   <li
		      key={it.id}
		      onClick={() => { window.location.hash = `#/item?id=${it.id}`; }}
		      style={{ cursor: "pointer", padding: "6px 0" }}
		      title="Open item"
		    >
		      <strong>{it.name || "(naamloos)"}</strong> — ID {it.id}
		    </li>
		  ))}
		</ul>
          )}
        </>
      )}
    </div>
  );
}

